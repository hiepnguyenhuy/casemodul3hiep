package com.example.casestudymodul3.model;

public class hiep {
    private String name;
}
