package com.example.casestudymodul3.model;

public class Linh {
    private String name;
}
